function y2 = output22(b)
j3 = jagger23(b);
j4 = jagger24(b);
y2 = j3+j4;
end
