b=1:1:452;
y21=output21(b);
y22=output22(b);
plot(b,y21)
hold on
plot(b,y22)
hold on
plot(B)