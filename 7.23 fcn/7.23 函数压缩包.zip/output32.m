function y2 = output32(b)
j3 = jagger33(b);
j4 = jagger34(b);
y2 = j3+j4;
end
