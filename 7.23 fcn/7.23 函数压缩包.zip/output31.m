
function y1 = output31(b)
j1 = jagger31(b);
j2 = jagger32(b);
y1 = j1+j2;
end
