function y = result2(b,q)

y = Sq2t1(b,q) + Sq2t2(b,q) + (1 - q) * Sq2t1(b,q) * Sq2t2(b,q);
end