
function y1 = output11(b)
j1 = jagger11(b);
j2 = jagger12(b);
y1 = j1+j2;
end
