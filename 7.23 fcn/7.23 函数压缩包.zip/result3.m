function y = result3(b,q)

y = Sq3t1(b,q) + Sq3t2(b,q) + (1 - q) * Sq3t1(b,q) * Sq3t2(b,q);
end