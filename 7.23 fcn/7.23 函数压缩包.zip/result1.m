function y = result1(b,q)

y = Sq1t1(b,q) + Sq1t2(b,q) + (1 - q) * Sq1t1(b,q) * Sq1t2(b,q);
end