b=1:1:452;
y11=output11(b);
y12=output12(b);
plot(y11)
grid on
hold on
plot(y12)
hold on
plot(A)
