function y2 = output12(b)
j3 = jagger13(b);
j4 = jagger14(b);
y2 = j3+j4;
end
