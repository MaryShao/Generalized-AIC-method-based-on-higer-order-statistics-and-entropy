
function y1 = output21(b)
j1 = jagger21(b);
j2 = jagger22(b);
y1 = j1+j2;
end
